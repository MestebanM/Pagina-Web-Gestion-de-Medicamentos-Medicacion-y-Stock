/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author LEIDY GIRALDO
 */
public class Funcionario {
    String nombre;
    String apellido;
    String correo;
    String edad;
    String usuario;
    String contrasenia;
    String confirmarContra;
    String genero;

    public Funcionario(String nombre, String apellido, String correo, String edad, String usuario, String contrasenia, String confirmarContra, String genero) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.edad = edad;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.confirmarContra = confirmarContra;
        this.genero = genero;
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
 

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String getConfirmarContra() {
        return confirmarContra;
    }

    public void setConfirmarContra(String confirmarContra) {
        this.confirmarContra = confirmarContra;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }
    
    
    
    
}
