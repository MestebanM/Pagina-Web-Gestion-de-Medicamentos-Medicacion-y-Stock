/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxy1;



/**
 *
 * @author marin
 */
public interface Medicamento {
    
    void eliminar(String id);
}
